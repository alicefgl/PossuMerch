using System.ComponentModel.DataAnnotations;
namespace PossuMerch.Data;

public class Prodotto
{
    [Key]
    public string? _NomeP { get; set; }
    public int? quantita { get; set; } 
    public Tipo tipoP { get; set; }
    public float prezzo { get; set; }
    public enum Tipo{
        Chitarra,
        Basso
    }
}